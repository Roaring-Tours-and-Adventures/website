export function estimate(rates:any[],pickup:string,guests:number,roundtrip?:boolean):number|null;
