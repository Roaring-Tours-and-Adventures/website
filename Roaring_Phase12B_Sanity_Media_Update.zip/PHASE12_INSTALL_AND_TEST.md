# Roaring Tours — Phase 1.2B media + Sanity update

## What this update does
- Preserves the existing multi-service booking cart and product pricing code.
- Adds 33 real photographs sourced from your 3 original media archives, optimized as WebP. **Original archives remain unchanged.**
- Uses the aerial reef photo RT-137 as the homepage hero while no Sanity hero has been published.
- Adds a responsive guest moments gallery using six of your original photographs.
- Expands the existing Sanity Studio schemas for SEO text, reviews, galleries, and video inventory records.
- Preserves local catalog content when Sanity is empty or temporarily unavailable.
- Corrects default business email and social links, and directs reviews to Tripadvisor.

## Install in your existing GitHub Codespace
1. In Codespaces, use **Source Control** to save your current website changes first; verify `.env.local` is NOT included.
2. In Codespaces **Explorer**, right-click the `website` folder and **Upload** this ZIP into the project root.
3. Open the terminal in `/workspaces/website`. Run:
   ```bash
   cd /workspaces/website
   unzip -o Roaring_Phase12B_Sanity_Media_Update.zip -d .
   npm install
   npm test
   npm run build
   npm run dev
   ```
4. Open the website preview. Check the aerial reef hero and guest photos. Visit `/studio` and sign in using your Sanity account.
5. If Studio displays a CORS warning, in Sanity Manage → API → CORS Origins, add the precise Codespaces preview origin beginning `https://` and enable credentials. **Do not use a wildcard origin.**
6. In Studio, create one **Homepage & business settings** document, add its title and optionally upload your hero photograph. Publish. Verify the homepage updates after a refresh (up to 60 seconds).
7. In Studio, create an **Approved guest review** only with the exact real review and its source link. Publish once approved.
8. Confirm `/book` still works and verify amounts before using any production payments.

## Important constraints
- The media package does **not** automatically upload all 178 assets to Sanity. It contains 33 optimized images selected for immediate visual testing and the RT-ID manifest. The source archives and complete media metadata remain separate.
- Your Sanity dataset is public. **Never store private booking data, guest email/phone, payment information, or credentials there.**
- Sanity `rates` values may not yet feed the cart calculations. Treat pricing as draft until product/Sanity data integration and tests are completed.
- Do not use Codespaces preview URLs for real customer bookings. Calendar, PayPal and secure booking back end remain unimplemented.
- Do not modify DNS, cancel Squarespace, or transfer Google Workspace while testing.
- `.env.local` must contain NEXT_PUBLIC_SANITY_PROJECT_ID=qfo1ra5k and NEXT_PUBLIC_SANITY_DATASET=production, and must remain gitignored.

## Validation
Expected `npm test` to run the existing pricing and cart tests. `npm run build` validates compilation and routing. These tests do not validate live checkout, approvals or emails. Do a manual check of mobile views and Sanity publishing.
