import catalog from '../content/catalog.json';
export const destinations=[['negril','Negril & Western Jamaica'],['montego-bay','Montego Bay'],['ocho-rios','Ocho Rios'],['kingston','Kingston'],['port-antonio','Port Antonio & Portland'],['south-coast','South Coast']];
export const defaults:Record<string,any>={title:'Experience Jamaica Your Way',phone:'18768394976',email:'tours@roaring-adventures.com',heroImage:'/media/jamaica-aerial-reef-view-137.webp',heroSubtitle:'Private transportation. Authentic experiences. Personalized adventures.',sections:['services','destinations','featured','about','reviews','offers','guides','partners'],facebook:'https://www.facebook.com/share/1JEXkhJXKP/',instagram:'https://www.instagram.com/roaringtoursja/',tiktok:'https://www.tiktok.com/@roaring.tours.and'};
const reviewsPage='https://www.tripadvisor.com/Attraction_Review-g147311-d34115485-Reviews-Roaring_Tours_and_Adventures-Montego_Bay_Saint_James_Parish_Jamaica.html';
export const reviewLink=reviewsPage;
export async function content(){
 const id=process.env.NEXT_PUBLIC_SANITY_PROJECT_ID;const ds=process.env.NEXT_PUBLIC_SANITY_DATASET||'production';
 const fallback={products:catalog as any[],settings:defaults,pages:[] as any[],reviews:[] as any[]};
 if(!id || id==='placeholder')return fallback;
 const query=`{"products":*[_type=="product"]{...,"image":image.asset->url},"settings":*[_type=="settings"][0]{...,"heroImage":heroImage.asset->url},"pages":*[_type=="page"]{...,"image":image.asset->url},"reviews":*[_type=="review" && approved==true]|order(_createdAt desc)}`;
 try{
  const res=await fetch(`https://${id}.api.sanity.io/v2025-01-01/data/query/${ds}?query=${encodeURIComponent(query)}`,{next:{revalidate:60}});
  if(!res.ok){console.error('Sanity fetch failed:',res.status);return fallback;}
  const {result}=await res.json();
  const products=Array.isArray(result?.products)&&result.products.length?result.products:catalog;
  const settings={...defaults,...(result?.settings||{})};
  if(!settings.heroImage)settings.heroImage=defaults.heroImage;
  if(!Array.isArray(settings.sections)||!settings.sections.length)settings.sections=defaults.sections;
  return {products,settings,pages:Array.isArray(result?.pages)?result.pages:[],reviews:Array.isArray(result?.reviews)?result.reviews:[]};
 }catch(err){console.error('Sanity unavailable, using preview content:',err);return fallback;}
}
